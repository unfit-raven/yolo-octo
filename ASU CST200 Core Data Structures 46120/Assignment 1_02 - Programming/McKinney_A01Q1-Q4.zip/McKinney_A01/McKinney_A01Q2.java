// McKinney_A01Q2.java
/*
	Q2: Write an application that displays your initials in large block letters. 
	Make each large letter out of the corresponding regular character. 
	Please see the following example for JAL. [10 points]
*/

public class McKinney_A01Q2
{
	public static void main(String[] args)
	{
		System.out.println("RRRRRRRRR    PPPPPPPP    MM         MM");
		System.out.println("RR       RR  PP      PP  MMM       MMM");    
		System.out.println("RR       RR  PP      PP  MM MM   MM MM");    
		System.out.println("RR     RR    PP    PP    MM  MM MM  MM");    
		System.out.println("RRRRRRR      PPPPPP      MM   MMM   MM");         
		System.out.println("RR  RR       PP          MM         MM");      
		System.out.println("RR    RR     PP          MM         MM");     
		System.out.println("RR     RR    PP          MM         MM");    
		System.out.println("RR      RR   PP          MM         MM");    
	}
}